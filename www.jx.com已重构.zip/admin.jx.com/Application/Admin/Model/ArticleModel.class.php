<?php
namespace Admin\Model;


use Think\Model;

class ArticleModel extends BaseModel
{
    // 每个表单都有自己的验证规则
    protected $_validate = array(
        array('name','require','标题不能够为空'),
array('article_category_id','require','文章分类不能够为空'),
array('times','require','浏览次数不能够为空'),
array('inputtime','require','录入时间不能够为空'),
array('status','require','状态@radio|1=是&0=否不能够为空'),
array('sort','require','排序不能够为空'),


    );
}