<?php
namespace Admin\Model;


use Think\Model;

class GoodsModel extends BaseModel
{
    // 每个表单都有自己的验证规则
    protected $_validate = array(
        array('name','require','名称不能够为空'),
array('sn','require','货号不能够为空'),
array('goods_category_id','require','父分类不能够为空'),
array('brand_id','require','品牌不能够为空'),
array('supplier_id','require','供货商不能够为空'),
array('shop_price','require','本店价格不能够为空'),
array('market_price','require','市场价格不能够为空'),
array('stock','require','库存不能够为空'),
array('is_on_sale','require','是否上架@radio|1=是&0=否不能够为空'),
array('goods_status','require','商品状态不能够为空'),
array('keyword','require','关键字不能够为空'),
array('logo','require','LOGO@file不能够为空'),
array('status','require','状态@radio|1=是&0=否不能够为空'),
array('sort','require','排序不能够为空'),


    );
}