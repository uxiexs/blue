<?php
/**
 * Created by PhpStorm.
 * User: uxeix
 * Date: 2016/1/8
 * Time: 0:06
 */

namespace Admin\Controller;


use Think\Controller;

class TestController extends Controller
{
    public function index(){
        echo phpinfo();
    }
}