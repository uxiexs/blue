<?php
namespace Admin\Controller;


use Think\Controller;

class ArticleController extends BaseController
{
    protected $meta_title = '文章分类';
}