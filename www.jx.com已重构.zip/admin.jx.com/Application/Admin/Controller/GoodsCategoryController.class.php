<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/1/9
 * Time: 11:50
 */

namespace Admin\Controller;


class GoodsCategoryController extends BaseController
{
    protected $meta_title = '商品分类';

}