<?php
/**
 * Created by PhpStorm.
 * User: uxeix
 * Date: 2016/1/12
 * Time: 0:30
 */
echo phpinfo();