//下面的代码在页面加载完毕后执行
$(function(){
  //>>1.通用ajax-get请求
  $('.ajax-get').click(function(){
    //>>1.发送ajax请求
    //从当前标签获得URL地址
    var url = $(this).attr('href');
    //回调函数中的data表示响应数据
    $.get(url,showAjaxLayer);
    return false;

  });


  //>>2.通用的post请求
$('.ajax-post').click(function(){
  //定位form,通过当前按钮往上定位‘form’标签所在对象
  var form = $(this).closest('form');
  //console.debug(form);
  //获取form对象的url地址
  //var url = form.attr('action');
  //console.debug(url);
  //序列化orm中的请求参数
  //var params = form.serialize();
  //console.debug(params);
  //$.post(url,params,showAjaxLayer);
  //console.debug(form.info);
  if (form.length!=0){
    form.ajaxSubmit({success:showAjaxLayer});
  }else {
    var url = $(this).attr('url');
    var params = $('.ids:checked').serialize();
    //console.debug(url);
    //console.debug(params);
    //console.debug(form.length);
    $.post(url,params,showAjaxLayer)
  }

  return false;//取消后续操作
})

  function  showAjaxLayer(data){
      var icon;
        console.debug(data);
        if(data.status){
          icon = 1; //success
        }else{
          icon = 2; //faild
        }
        layer.msg(data.info,{
          time:1000, //time
          offset:0, //location
          shift:5,  //Special effects
          icon:icon
        },function(){
          if(data.url){
            location.href=data.url;
          }
        });

      //}

    }
});
//实现全选影响到下面的复选框的选中效果
$('.selectAll').click(function(){
  $('.ids').prop('checked',$(this).prop('checked'));
});

$('.ids').click(function(){
  $('.selectAll').prop('checked',$('.ids:not(:checked)').length==0);
});