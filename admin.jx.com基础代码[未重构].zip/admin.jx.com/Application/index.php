<?php
/**
 * Created by PhpStorm.
 * User: uxeix
 * Date: 2016/1/8
 * Time: 1:06
 */
echo phpinfo();