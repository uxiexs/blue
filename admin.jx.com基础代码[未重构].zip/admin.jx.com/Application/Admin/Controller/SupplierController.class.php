<?php


namespace Admin\Controller;


use Think\Controller;

class SupplierController extends Controller
{
    /**
     * 主页
     */
    public function index(){
        //>>1.创建模型对象
        $model = D('supplier');

        //>>2.使用模型查询数据库中状态>-1数据
        /**
         * $pageResult = >array(
        'rows'=>二维数组.   分页列表数据
        'pageHtml'=>分页工具条的html.
         * )
         */
        //查询关键字
        $keyword = I('get.keyword','');
        $wheres = array();
        if(!empty($keyword)){
            $wheres['name'] = array("like","%{$keyword}%");
        }
        $pageResult = $model->getPageResult($wheres);
        //>>3.将数据分配到页面上
        $this->assign($pageResult);

        //>>将当前url地址保存在cookie中
        //dump($_SERVER['REQUEST_URI']);
        cookie('__forward__',$_SERVER['REQUEST_URI']);

        //>>4.选择视图页面
        $this->display('index');
    }

    /**
     * 添加商品方法
     */
    public function add(){
        if(IS_POST){
            //>>1.创建模型对象
            $model = D('Supplier');
            //>>2.使用模型中的create方法进行收集数据并且验证
            if($model->create()!==false){
                //>>3.请求数据添加到数据库中
                if($model->add()!==false){
                    $this->success('添加成功!',U('index'));
                    return;//防止下面的代码继续执行.
                }
            }
            $this->error('操作失败!'.show_model_error($model));
        }else{
            $this->display('edit');
        }
    }
//
//     changeStatus也能删除，与此方法重复，故隐藏
//    public function remove($id){
//        //>>1.创建模型对象
//        $model = D('supplier');
//        //>>2.使用模型对象中的delte方法删除
//        $result = $model->remove($id);
//        if($result!==false){
//            $this->success('删除成功!',U('index'));
//        }else{
//            $this->error('删除失败!'.show_model_error($model));
//        }
//    }

    /**
     * 编辑方法
     * 根据id进行编辑
     * @param $id
     */
    public function edit($id){
        $model = D('Supplier');
        if(IS_POST){
            //>>1.使用模型中的create来接收请求参数
            if($model->create()!==false){
                //>>2.将请求参数修改到数据库中
                if($model->save()!==false){
                    $this->success('修改成功!',cookie('__forward__'));
                    return;
                }
            }
            $this->error('操作失败!'.show_model_error($model));
        }
        else{
            //>>1.使用模型查询出id对应的数据
            $row = $model->find($id);
            //>>2.将数据分配到页面上
            $this->assign($row);
            //>>3.显示edit页面回显数据
            $this->display('edit');
        }
    }

    /**
     * 移除方法以及修改status方法
     * 根据id找到其将其状态改为status的值
     * @param $id
     * @param $status
     */
    public function changeStatus($id,$status=-1){
        //>>1.创建模型
        $model = D('Supplier');
        //>>2.使用模型中的changeStatus修改数据的状态
        $result = $model->changeStatus($id,$status);
        if($result!=false){
            $this->success('操作成功',cookie('__forward__'));
        }
        else{
            $this->error('修改失败'.show_module_error('$model'));
        }
    }
}