<?php
/**
 * Created by PhpStorm.
 * User: uxeix
 * Date: 2016/1/8
 * Time: 0:12
 */

namespace Admin\Controller;


use Think\Controller;

class SupplierController extends Controller
{
        public function index(){
            //>>1.创建模型对象
            $model = D('supplier');
            //>>2.使用模型查询数据表
            $rows = $model->select();
            //>>3.将数据分配到页面上
            $this->assign('rows',$rows);
            //>>4.选择视图
            $this->display('index');
        }
        public  function  add(){

            //>>1.创建模型对象
             $model = D('supplier');
            //>>2.使用模型中的create方法进行搜集数据并验证
                if($model->create()!==false){
            //>>3.请求数据添加到数据表中
                    if($model->add()!==false){
                        $this->success('添加成功',U('index'));
                        return;
                    }

                $this->error('添加失败'.show_module_error($model));
            }else{
                $this->display('edit');
            }
        }

}