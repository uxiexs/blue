<?php


namespace Admin\Model;


use Think\Model;
use Think\Page;

class SupplierModel extends Model
{
    //开启批量验证
    protected $patchValidate = true;
    // 自动验证定义
    protected $_validate = array(
        array('name','require','名字不能够为空'),
        array('name','','名字不能重复','','unique'),
        array('intro','require','描述不能够为空'),
    );


    /**
     * 根据id未删除对应数据
     * @param $id
     * @return bool
     */
//    public function remove($id){
//        return parent::save(array('status'=>-1,'id'=>$id));
//    }

    /**
     * 得到分页列表中的数据
     * $pageResult = >array(
    'rows'=>二维数组.   分页列表数据
    'pageHtml'=>分页工具条的html.
     * )
     */
    public function getPageResult($wheres=[]){
        //因为总条数和分页列表都需要查询出状态>-1的数据
        //$wheres = array();
        $wheres['status'] = array('gt',-1);


        //>>1.准备分页工具条html
        $pageHtml= '';
        $pageSize = 6;  //每页多少条
        $totalRows = $this->where($wheres)->count();  //总条数
        $page = new Page($totalRows,$pageSize);
        $pageHtml = $page->show();//生成分页的html

        //>>2.准备分页列表数据
        //$row = $this->where($wheres)->limit($page->firstRow,$page->listRows)->select();
        //$row = $this->where($wheres)->page($_GET['p'],$page->listRows)->select();
        //$page->firstRow 起始条数= （页码-1）*每页条数
        //dump($page->firstRow);
        if($page->firstRow >= $totalRows){     //如果起始条数大于总条数
            $page->firstRow = $totalRows - $page->listRows;  //起始条数等于总条数减去每页条数
        }
        //dump($page->firstRow);
        $row = $this->where($wheres)->page($_GET['p'],$page->listRows)->select();
        return array('rows'=>$row,'pageHtml'=>$pageHtml);
    }


    /**
     * 查询出状态大于-1
     */
    public function getList(){
        return $this->where(array('status'=>array('gt',-1)))->select();
    }

//
//    /**
//     * 根据id修改数据表中status的值
//     * @param $id
//     * @param $status
//     */

    public function changeStatus($id,$status=-1){
        $data = array('id'=>array('in',$id),'status'=>$status);
//        var_dump($date);
//        exit;
        if($status==-1){
            $data['name'] = array('exp',"concat(name,'_del')");
        }
        return parent::save($data);
    }
}