<?php
namespace Admin\Controller;


use Think\Controller;

class SupplierController extends BaseController
{
    protected $meta_title = '供应商';
}