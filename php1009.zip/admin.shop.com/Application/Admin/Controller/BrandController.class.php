<?php
namespace Admin\Controller;


use Think\Controller;

class BrandController extends BaseController
{
    protected $meta_title = '商品品牌';
}