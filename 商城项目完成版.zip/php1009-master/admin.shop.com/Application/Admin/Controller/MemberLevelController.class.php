<?php
namespace Admin\Controller;


use Think\Controller;

class MemberLevelController extends BaseController
{
    protected $meta_title = '会员级别';
}