<?php
namespace Admin\Controller;


use Think\Controller;

class ArticleCategoryController extends BaseController
{
    protected $meta_title = '文章分类';
}