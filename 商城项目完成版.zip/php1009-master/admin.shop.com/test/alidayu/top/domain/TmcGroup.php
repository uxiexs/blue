<?php

/**
 * 消息通道的分组结构
 * @author auto create
 */
class TmcGroup
{
	
	/** 
	 * 分组名称
	 **/
	public $name;
	
	/** 
	 * 用户列表
	 **/
	public $users;	
}
?>